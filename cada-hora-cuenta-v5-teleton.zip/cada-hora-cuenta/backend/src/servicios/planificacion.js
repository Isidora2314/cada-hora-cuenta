// ------------------------------------------------------------
// Une las piezas: lee parámetros, horas de BUK y filas de
// planificación, y llama al motor de cálculo.
// ------------------------------------------------------------
const repo = require('../repositorio/archivoJson');
const { calcularFila } = require('./calculo');

// Carga todos los parámetros. "cambios" permite simular sin guardar:
//   cargarParametros({ generales: { porcentajeMetaGestion: 0.85 } })
function cargarParametros(cambios = {}) {
  const generales = {};
  repo.leer('parametros_generales').forEach((g) => { generales[g.clave] = g.valor; });
  return {
    distribucion: cambios.distribucion || repo.leer('distribucion'),
    factorGrupal: cambios.factorGrupal || repo.leer('factor_grupal'),
    calendario: cambios.calendario || repo.leer('calendario'),
    generales: { ...generales, ...(cambios.generales || {}) },
  };
}

// Horas semanales de cada mes (ene..dic) para una fila de planificación.
//  - Multi-instituto: se usan las horas de la hoja Excepciones para ESE instituto
//  - Resto: horas del reporte BUK; los meses que BUK aún no informa
//    repiten el último valor conocido (salvo que el contrato termine antes)
function horasPorMes(fila, indiceBuk, excepciones) {
  if (fila.excepId) {
    const e = excepciones.find((x) => x.excepId === fila.excepId);
    if (e) return e.horasPorMes;
  }
  const registros = indiceBuk[`${fila.personaId}|${fila.it}`] || {};
  const horas = [];
  let ultimo = null;
  for (let m = 1; m <= 12; m++) {
    const r = registros[m];
    if (r) {
      ultimo = r;
      horas.push(r.horasSemanales || 0);
    } else if (ultimo && m > ultimoMes(registros)) {
      // Mes futuro: sigue igual, salvo que el contrato ya haya terminado
      const termino = ultimo.fechaTermino ? Number(ultimo.fechaTermino.slice(5, 7)) : 12;
      const terminoAnio = ultimo.fechaTermino ? Number(ultimo.fechaTermino.slice(0, 4)) : 2026;
      horas.push(terminoAnio > 2026 || m <= termino ? ultimo.horasSemanales : 0);
    } else {
      horas.push(0);
    }
  }
  return horas;
}

function ultimoMes(registros) {
  return Math.max(0, ...Object.keys(registros).map(Number));
}

// Índice de BUK: "personaId|it" -> { mes: registro }
function indexarBuk(dotacion) {
  const indice = {};
  dotacion.forEach((r) => {
    const clave = `${r.personaId}|${r.it}`;
    if (!indice[clave]) indice[clave] = {};
    indice[clave][Number(r.periodo.slice(5, 7))] = r;
  });
  return indice;
}

// Calcula todas las filas (o las que se pasen) con los parámetros dados
function calcularTodo({ parametros, filas } = {}) {
  const p = parametros || cargarParametros();
  const lista = filas || repo.leer('planificacion_base');
  const indiceBuk = indexarBuk(repo.leer('dotacion'));
  const excepciones = repo.leer('excepciones');
  return lista.map((fila) => calcularFila(fila, horasPorMes(fila, indiceBuk, excepciones), p));
}

module.exports = { cargarParametros, calcularTodo, horasPorMes, indexarBuk };
