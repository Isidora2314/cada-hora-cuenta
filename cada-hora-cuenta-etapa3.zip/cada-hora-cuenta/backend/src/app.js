// ------------------------------------------------------------
// Configuración de la aplicación Express (sin levantar el puerto).
// Se separa de server.js para poder usarla en los tests.
// ------------------------------------------------------------
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const repo = require('./repositorio/archivoJson');
const { validarApiKeyBot } = require('./middleware/botApiKey');

const app = express();
app.use(cors());
app.use(express.json({ limit: '20mb' })); // el bot enviará reportes grandes

// Ruta de prueba: cuántos registros hay en cada tabla
app.get('/api/salud', (req, res) => {
  const tablas = [
    'institutos', 'homologacion', 'distribucion', 'asignaciones_catalogo',
    'factor_grupal', 'calendario', 'parametros_generales',
    'excepciones', 'dotacion', 'referencia_excel', 'usuarios',
  ];
  const resumen = {};
  tablas.forEach((t) => { resumen[t] = repo.leer(t).length; });
  res.json({ estado: 'ok', registros: resumen });
});

// Rutas de la aplicación
app.use('/api/auth', require('./rutas/auth'));
app.use('/api/usuarios', require('./rutas/usuarios'));
app.use('/api/profesionales', require('./rutas/profesionales'));
app.use('/api/parametros', require('./rutas/parametros'));
app.use('/api', require('./rutas/planificacion')); // /api/planificacion y /api/simulaciones

// Rutas del bot (Blue Prism). En la etapa 4 se agregan /buk, /sic, /errores y /estado
app.get('/api/bot/ping', validarApiKeyBot, (req, res) => {
  res.json({ mensaje: 'Conexión con Blue Prism OK' });
});

module.exports = app;
